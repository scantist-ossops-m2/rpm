#ifndef LREXLIB_H
#define LREXLIB_H

int luaopen_rex(lua_State *L);

#endif
